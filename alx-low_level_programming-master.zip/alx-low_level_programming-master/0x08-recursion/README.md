#!/bin/bash
0. She locked away a secret, deep inside herself, something she once knew to be true... but chose to forget
1. Why is it so important to dream? Because, in my dreams we are together2. Dreams feel real while we're in them. It's only when we wake up that we realize something was actually strange
3. You mustn't be afraid to dream a little bigger, darling

