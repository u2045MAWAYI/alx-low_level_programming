File descriptors and permissions
