#C - Even more pointers, arrays and strings
You can use them to test your functions, but you don’t have to push them to your repo (if you do we won’t take them into account).
