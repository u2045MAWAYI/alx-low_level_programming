#ifndef _CODING_H_
#define _CODING_H_
#include <stdio.h>
/**
 * struct list_s - it's a singly linked list
 * @str: string - (malloc'ed string)
 * @len: length of the strings
 * @next: points to the next node
 *
 * Description: singly linked list node structure
 * for Coding project
 */
typedef struct list_s
{
	char *str;
	unsigned int len;
	struct list_s *next;
} list_t;

size_t print_list(const list_t *h);
size_t list_len(const list_t *h);
list_t *add_node(list_t **head, const char *str);
list_t *add_node_end(list_t **head, const char *str);
void free_list(list_t *head);

char *_strdup(const char *str);
#endif
