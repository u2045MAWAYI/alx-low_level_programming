0. Float like a butterfly, sting like a bee
1. The woman who has no imagination has no wings
2. He who is not courageous enough to take risks will accomplish nothing in life
3. If you even dream of beating me you'd better wake up and apologize
4. It's not bragging if you can back it up
