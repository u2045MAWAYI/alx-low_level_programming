#include <stdio.h>

/**
 * main - will print the names of the file
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
