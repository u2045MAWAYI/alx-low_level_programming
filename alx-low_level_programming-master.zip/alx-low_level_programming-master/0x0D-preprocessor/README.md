Object-like Macro Create a header file that defines a macro named SIZE as an abbreviation for the token 1024.

Pi mandatory Create a header file that defines a macro named PI as an abbreviation for the token 3.14159265359.

File name mandatory Write a program that prints the name of the file it was compiled from, followed by a new line.

Function-like macro mandatory Write a function-like macro ABS(x) that computes the absolute value of a number x.

SUM mandatory Write a function-like macro SUM(x, y) that computes the sum of the numbers x and y
