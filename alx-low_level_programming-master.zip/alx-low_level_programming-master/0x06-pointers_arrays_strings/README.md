0x06-pointers arrays strings
