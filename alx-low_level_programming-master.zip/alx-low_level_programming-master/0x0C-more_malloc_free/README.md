0x0C. C - More malloc, free
0. Trust no one
1. string nconcat
2. _calloc
