 C file name will be saved in the variable $CFILE
